# Generated figures:

<img src="images/1 - Signal.png" width="779" height="414" />
<img src="images/2 - Doppler Response.png" width="779" height="414" />
<img src="images/3 - CFAR.png" width="779" height="414" />
